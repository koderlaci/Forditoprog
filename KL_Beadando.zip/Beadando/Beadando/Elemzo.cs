﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beadando
{
    class Elemzo
    {
        string input;
        public string Input {
            get { return input; }
        }

        string[] oszlop;
        public string[] Oszlop {
            get { return oszlop; }
        }

        string[] sor;
        public string[] Sor {
            get { return sor; }
        }

        public List<string> lepesenkent = new List<string>();
        public List<string> kifejezesek = new List<string>();
        public List<string> inputok = new List<string>();

        Stack<string> verem = new Stack<string>();

        string[,] szabalyok;
        string szabalyokOsszeg;
        int szabalySzama;
        int index;

        public string[] GetSor(int index)
        {
            string[] sor = new string[szabalyok.GetLength(1)];
            for (int i = 0; i < sor.Length; i++)
                sor[i] = szabalyok[index, i];
            return sor;
        }

        public string Start(string input)
        {
            this.input = input;
            index = 0;
            lepesenkent.Clear();
            kifejezesek.Clear();
            verem.Clear();
            verem.Push("#");
            verem.Push("E");
            szabalyokOsszeg = "";

            string eredmeny;
            do{
                eredmeny = Elemzes();
            }while (eredmeny == "");
            return eredmeny;
        }

        public string[] Zarojel(string szabaly)
        {
            if (szabaly != "")
            {
                if (szabaly[0] == '(')
                {
                    szabaly = szabaly.Substring(1, szabaly.Length - 2);
                }
                if (szabaly.Contains(","))
                {
                    szabalySzama = int.Parse(szabaly.Split(',')[1]);
                    return szabaly.Split(',')[0].Split(' ');
                }
                else
                {
                    szabalySzama = -1;
                    return new string[] { szabaly };
                }
            }
            else
            {
                szabalySzama = -1;
                return new string[] { szabaly };
            }
        }

        private string Elemzes()
        {
            string vizsgaltKarakter = input[index].ToString();

            string[] temp = new string[10];
            verem.CopyTo(temp, 0);
            kifejezesek.Add(temp[0]);
            inputok.Add(vizsgaltKarakter);

            string szabaly = verem.Pop();

            string[] szabalyok = GetSzabaly(vizsgaltKarakter, szabaly);

            if (szabalySzama != -1)
            {
                szabalyokOsszeg = szabalyokOsszeg + " " + szabalySzama;
            }
            lepesenkent.Add(szabalyokOsszeg);

            if (szabalyok[0] == "")
            {
                return "A vizsgált kifejezés helytelen elemet tartalmaz a " + index + ". helyen.";
            }
            else if (szabalyok[0] == "elfogad")
            {
                return "A vizsgált kifejezés helyes.";
            }
            else if (szabalyok[0] == "pop")
            {
                index++;
            }
            else if (szabalyok[0] != "e")
            {
                for (int i = szabalyok.Length - 1; i >= 0; i--)
                {
                    verem.Push(szabalyok[i]);
                }
            }
            return "";
        }

        public void SzabalyBeolvasas()
        {
            StreamReader sr = new StreamReader(File.OpenRead("szabalyok.txt"));
            List<string> sorok = new List<string>();
            while (!sr.EndOfStream)
                sorok.Add(sr.ReadLine());
            for (int i = 0; i < sorok.Count; i++){
                string[] elemek = sorok[i].Split(';');
                if (i == 0){
                    oszlop = new string[elemek.Length - 2];
                    for (int j = 0; j < elemek.Length - 2; j++){
                        oszlop[j] = elemek[j + 1];
                    }
                }
                else{
                    if (sor == null){
                        sor = new string[sorok.Count - 1];
                    }
                        
                    if (szabalyok == null){
                        szabalyok = new string[sor.Length, oszlop.Length];
                    }
                    sor[i - 1] = elemek[0];
                    for (int j = 1; j < elemek.Length - 1; j++){
                        szabalyok[i - 1, j - 1] = elemek[j];
                    }
                }
            }
        }

        private string[] GetSzabaly(string oszlop, string sor)
        {
            int sorIndex = -1;
            int oszlopIndex = -1;

            for (int i = 0; i < this.sor.Length; i++){
                if (this.sor[i] == sor){
                    sorIndex = i;
                }  
            }
            for (int i = 0; i < this.oszlop.Length; i++){
                if (this.oszlop[i] == oszlop){
                    oszlopIndex = i;
                }
            }
            string szabaly;
            if(sorIndex != -1 && oszlopIndex != -1){
                szabaly = szabalyok[sorIndex, oszlopIndex];
            }
            else{
                szabaly = "";
            }

            string[] temp = Zarojel(szabaly);

            return temp;
        }
    }
}
