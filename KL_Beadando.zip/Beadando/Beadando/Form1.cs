﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Beadando
{
    public partial class Form1 : Form
    {
        Elemzo elemzo;
        public Form1()
        {
            InitializeComponent();
            elemzo = new Elemzo();
            elemzo.SzabalyBeolvasas();
            SzabalyokFeltoltes();
        }

        private void SzabalyokFeltoltes()
        {
            dataGridView.ColumnCount = elemzo.Oszlop.Length;
            for (int i = 0; i < elemzo.Oszlop.Length; i++)
            {
                dataGridView.Columns[i].Name = elemzo.Oszlop[i];
                dataGridView.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
            }
            for (int i = 0; i < elemzo.Sor.Length; i++)
            {
                dataGridView.Rows.Add(elemzo.GetSor(i));
                dataGridView.Rows[i].HeaderCell.Value = elemzo.Sor[i];
            }
        }

        private void MegoldasFeltoltes()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Input", typeof(string));
            dt.Columns.Add("Kifejezés", typeof(string));
            dt.Columns.Add("Szabály", typeof(string));

            for (int i = 0; i < elemzo.kifejezesek.Count; i++)
            {
                dt.Rows.Add(elemzo.inputok[i], elemzo.kifejezesek[i], elemzo.lepesenkent[i]);
            }

            dataGridView1.DataSource = dt;
        }

        private void button_start_Click(object sender, EventArgs e)
        {
            textBox_egyszerusitett.Text = Regex.Replace(textBox_input.Text, "([0-9]+)", "i") + "#";
            textBox_eredmeny.Text = elemzo.Start(textBox_egyszerusitett.Text);
            MegoldasFeltoltes();
        }
    }
}
