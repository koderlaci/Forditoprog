﻿
namespace Beadando
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox_input = new System.Windows.Forms.TextBox();
            this.textBox_egyszerusitett = new System.Windows.Forms.TextBox();
            this.label_input = new System.Windows.Forms.Label();
            this.label_egyszerusitett = new System.Windows.Forms.Label();
            this.button_start = new System.Windows.Forms.Button();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.textBox_eredmeny = new System.Windows.Forms.TextBox();
            this.label_eredmeny = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox_input
            // 
            this.textBox_input.Location = new System.Drawing.Point(130, 407);
            this.textBox_input.Name = "textBox_input";
            this.textBox_input.Size = new System.Drawing.Size(564, 22);
            this.textBox_input.TabIndex = 0;
            // 
            // textBox_egyszerusitett
            // 
            this.textBox_egyszerusitett.Location = new System.Drawing.Point(130, 437);
            this.textBox_egyszerusitett.Name = "textBox_egyszerusitett";
            this.textBox_egyszerusitett.Size = new System.Drawing.Size(564, 22);
            this.textBox_egyszerusitett.TabIndex = 1;
            // 
            // label_input
            // 
            this.label_input.AutoSize = true;
            this.label_input.Location = new System.Drawing.Point(12, 410);
            this.label_input.Name = "label_input";
            this.label_input.Size = new System.Drawing.Size(43, 17);
            this.label_input.TabIndex = 2;
            this.label_input.Text = "Input:";
            // 
            // label_egyszerusitett
            // 
            this.label_egyszerusitett.AutoSize = true;
            this.label_egyszerusitett.Location = new System.Drawing.Point(12, 437);
            this.label_egyszerusitett.Name = "label_egyszerusitett";
            this.label_egyszerusitett.Size = new System.Drawing.Size(101, 17);
            this.label_egyszerusitett.TabIndex = 3;
            this.label_egyszerusitett.Text = "Egyszerűsített:";
            // 
            // button_start
            // 
            this.button_start.Location = new System.Drawing.Point(726, 407);
            this.button_start.Name = "button_start";
            this.button_start.Size = new System.Drawing.Size(161, 80);
            this.button_start.TabIndex = 4;
            this.button_start.Text = "Start";
            this.button_start.UseVisualStyleBackColor = true;
            this.button_start.Click += new System.EventHandler(this.button_start_Click);
            // 
            // dataGridView
            // 
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Location = new System.Drawing.Point(12, 12);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.RowHeadersWidth = 51;
            this.dataGridView.RowTemplate.Height = 24;
            this.dataGridView.Size = new System.Drawing.Size(875, 383);
            this.dataGridView.TabIndex = 5;
            // 
            // textBox_eredmeny
            // 
            this.textBox_eredmeny.Location = new System.Drawing.Point(129, 465);
            this.textBox_eredmeny.Name = "textBox_eredmeny";
            this.textBox_eredmeny.Size = new System.Drawing.Size(565, 22);
            this.textBox_eredmeny.TabIndex = 6;
            // 
            // label_eredmeny
            // 
            this.label_eredmeny.AutoSize = true;
            this.label_eredmeny.Location = new System.Drawing.Point(12, 465);
            this.label_eredmeny.Name = "label_eredmeny";
            this.label_eredmeny.Size = new System.Drawing.Size(76, 17);
            this.label_eredmeny.TabIndex = 7;
            this.label_eredmeny.Text = "Eredmény:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(15, 503);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(872, 244);
            this.dataGridView1.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(903, 759);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label_eredmeny);
            this.Controls.Add(this.textBox_eredmeny);
            this.Controls.Add(this.dataGridView);
            this.Controls.Add(this.button_start);
            this.Controls.Add(this.label_egyszerusitett);
            this.Controls.Add(this.label_input);
            this.Controls.Add(this.textBox_egyszerusitett);
            this.Controls.Add(this.textBox_input);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_input;
        private System.Windows.Forms.TextBox textBox_egyszerusitett;
        private System.Windows.Forms.Label label_input;
        private System.Windows.Forms.Label label_egyszerusitett;
        private System.Windows.Forms.Button button_start;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.TextBox textBox_eredmeny;
        private System.Windows.Forms.Label label_eredmeny;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}

